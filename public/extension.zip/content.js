// content.js

/**
 * Evalis Transcript Exporter
 * Injects a button into the transcript page, parses the DOM for grades/GPAs,
 * and sends the data to the Evalis API.
 */
(function() {
  'use strict';

  /**
   * Parses the DOM to extract subject grades and trimester GPAs.
   * @returns {Object} Structured data { subjects: [], gpa: {} }
   */
  function extractTranscriptData() {
    const data = {
      subjects: [],
      gpa: {}
    };

    const rows = document.querySelectorAll('tr');

    // Regex to flexibly capture strings like "Trimester 1 GPA - 3" or "Trimester 2 GPA - 2.88"
    const gpaRegex = /Trimester\s+(\d+)\s+GPA\s*[-:]?\s*([\d.]+)/i;
    const avgGpaRegex = /Average\s+performance\s+GPA\s*[-:]?\s*([\d.]+)/i;

    // We will attempt to dynamically map columns based on table headers to avoid fragile indexing
    let subjectColIndex = -1;
    let pointsColIndex = -1;

    rows.forEach((row) => {
      const rowText = row.textContent.trim();

      // 1. Check if row is a GPA summary row
      const gpaMatch = rowText.match(gpaRegex);
      const avgGpaMatch = rowText.match(avgGpaRegex);
      if (gpaMatch) {
        const trimesterNum = parseInt(gpaMatch[1], 10);
        const gpaValue = parseFloat(gpaMatch[2]);
        
        // Handle potentially missing/invalid GPA values securely
        if (!isNaN(gpaValue)) {
          data.gpa[`trimester${trimesterNum}`] = gpaValue;
        }
        return; // Skip further processing for this row
      }

      if (avgGpaMatch) {
        const avgGpaValue = parseFloat(avgGpaMatch[1]);
        if (!isNaN(avgGpaValue)) {
          data.gpa.average = avgGpaValue;
        }
        return; // Skip further processing for this row
      }

      // 2. Identify column indexes dynamically from header rows (<th>)
      const headerCells = row.querySelectorAll('th');
      if (headerCells.length > 0 && subjectColIndex === -1) {
        headerCells.forEach((th, idx) => {
          const text = th.textContent.toLowerCase().trim();
          if (text.includes('subject name') || text.includes('discipline')) {
            subjectColIndex = idx;
          }
          if (text.includes('in points') || text === 'points') {
            pointsColIndex = idx;
          }
        });
        return; // Move to next row after processing headers
      }

      // 3. Fallbacks if no valid table headers were found
      // Based on prompt: Subject(0), Credits(1), %(2), Alpha(3), Points(4), Traditional(5)
      if (subjectColIndex === -1) subjectColIndex = 0;
      if (pointsColIndex === -1) pointsColIndex = 4;

      // 4. Parse Subject Rows (<td>)
      const dataCells = row.querySelectorAll('td');
      
      // Assume a valid subject row has enough columns to hold our target data
      if (dataCells.length >= 5) {
        const subjectName = dataCells[subjectColIndex]?.textContent.trim();
        const pointsText = dataCells[pointsColIndex]?.textContent.trim();
        const pointsValue = parseFloat(pointsText);

        // Validate the row actually contained legitimate subject data
        if (subjectName && !isNaN(pointsValue)) {
          data.subjects.push({
            name: subjectName,
            points: pointsValue
          });
        }
      }
    });

    return data;
  }

  /**
   * Handles the export process: extracts data, logs it, and posts to API
   */
  function extractEmail() {
    // Standard email regex
    const emailRegex = /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/gi;
    
    // Check common header/nav areas first to avoid catching random emails in page text
    const headerElements = document.querySelectorAll('header, nav, .navbar, .top-bar, .user-info');
    
    for (const el of headerElements) {
      const matches = el.textContent.match(emailRegex);
      if (matches && matches.length > 0) {
        return matches[0].trim().toLowerCase();
      }
    }

    // Fallback: Scan the top 20% of the entire body text
    const bodyText = document.body.innerText;
    const topText = bodyText.substring(0, bodyText.length * 0.2);
    const bodyMatches = topText.match(emailRegex);
    
    // Prioritize university or known domains if multiple are found
    if (bodyMatches) {
      const aituMatch = bodyMatches.find(e => e.includes('astanait.edu.kz'));
      return aituMatch ? aituMatch.toLowerCase() : bodyMatches[0].toLowerCase();
    }

    return null;
  }

  const SUPABASE_URL = 'https://xepictcozkcltiiukfqv.supabase.co';
  const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhlcGljdGNvemtjbHRpaXVrZnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI5Njc1NTQsImV4cCI6MjA3ODU0MzU1NH0.TD5EuAz4ikBhtGp4u5s0lIN7mZXbHC5OU9BeXaGU1Ao'; // VITE_SUPABASE_ANON_KEY

  async function handleExportClick(event) {
    const btn = event.target;
    const originalText = btn.textContent;

    try {
      // Update UI state
      btn.textContent = 'Extracting...';
      btn.disabled = true;
      btn.style.opacity = '0.8';

      const userEmail = extractEmail();
      if (!userEmail) {
        alert("Could not find your email address on the page. Please ensure you are logged in to the university portal.");
        throw new Error("Email not found on page.");
      }

      // Parse DOM
      const extractedData = extractTranscriptData();
      btn.textContent = 'Sending to Evalis...';

      const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/upload_transcript_by_email`, {
        method: 'POST',
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          p_email: userEmail,
          p_data: extractedData
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }

      const result = await response.json();

      if (result.error) {
        alert(`Evalis account not found for ${userEmail}. Please sign up on Evalis first!`);
        throw new Error(result.error);
      }

      // Success UI feedback
      btn.textContent = 'Success!';
      btn.style.backgroundColor = '#2E7D32'; // Darker green

    } catch (error) {
      console.error('Evalis Export Failed:', error);
      btn.textContent = 'Export Failed';
      btn.style.backgroundColor = '#D32F2F'; // Red
    } finally {
      // Reset button after 3 seconds
      setTimeout(() => {
        btn.textContent = originalText;
        btn.disabled = false;
        btn.style.backgroundColor = '#4CAF50';
        btn.style.opacity = '1';
      }, 4000);
    }
  }

  /**
   * Injects the floating export button into the DOM
   */
  function injectUI() {
    if (document.getElementById('evalis-export-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'evalis-export-btn';
    btn.textContent = 'Export to Evalis';
    
    // Modern inline styling to avoid external CSS files
    Object.assign(btn.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      padding: '14px 24px',
      backgroundColor: '#4CAF50',
      color: '#FFFFFF',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      zIndex: '999999',
      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
      fontWeight: '600',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      fontSize: '14px',
      transition: 'all 0.2s ease-in-out'
    });

    // Hover effects via JS events
    btn.addEventListener('mouseenter', () => btn.style.transform = 'translateY(-2px)');
    btn.addEventListener('mouseleave', () => btn.style.transform = 'translateY(0)');
    
    btn.addEventListener('click', handleExportClick);

    document.body.appendChild(btn);
  }

  // Ensure DOM is fully loaded before injection
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectUI);
  } else {
    injectUI();
  }

})();